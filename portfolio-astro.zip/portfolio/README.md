# Portfolio – Amrul Fadhil Yofan

Astro (statis) + konten proyek berbasis Markdown. Deploy otomatis ke GitHub Pages.

## Menjalankan
```bash
npm install
npm run dev      # http://localhost:4321
npm run build    # hasil di dist/
```

## Sebelum publish
1. Salin `img/ft.png` dari repo lama ke `public/img/ft.png` (dan optimalkan ke WebP).
2. Tambahkan `public/cv.pdf` dan `public/og.png` (1200×630).
3. GitHub → Settings → Pages → Source: **GitHub Actions**.
4. Push ke `main`; workflow `.github/workflows/deploy.yml` akan build dan deploy.

## Menambah proyek
Buat file baru di `src/content/projects/nama-proyek.md` (lihat frontmatter contoh).
Data situs (nama, tautan, skills, menu) ada di `src/data/site.ts`.

## Struktur
```
src/
  components/   Nav, Hero, About, ProjectCard, Skills, Contact, Footer
  content/projects/*.md
  layouts/Base.astro     (meta, OG, JSON-LD)
  pages/index.astro, 404.astro
  styles/tokens.css, global.css
public/  favicon.svg, robots.txt (+ ft.png, cv.pdf, og.png)
```

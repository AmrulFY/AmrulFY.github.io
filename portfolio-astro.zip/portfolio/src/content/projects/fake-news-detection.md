---
title: Fake News Detection
summary: Model NLP untuk mengklasifikasikan berita palsu dan asli.
tags: [Python, NLP, TensorFlow]
repo: https://github.com/AmrulFY/Submission-Model-NLP-123
order: 2
---
Tambahkan di sini: masalah, dataset, metode, dan hasil (metrik + grafik).

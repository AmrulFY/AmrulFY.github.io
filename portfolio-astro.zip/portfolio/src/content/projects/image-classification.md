---
title: Image Classification
summary: Model deep learning (CNN) untuk klasifikasi gambar, lengkap dengan deployment.
tags: [Python, CNN, Deployment]
repo: https://github.com/AmrulFY/Submission-Image-Classification-Model-Deployment-123
order: 3
---
Tambahkan di sini: masalah, dataset, metode, dan hasil (metrik + grafik).

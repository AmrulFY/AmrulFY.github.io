export const site = {
  name: 'Amrul Fadhil Yofan',
  title: 'Amrul Fadhil Yofan – Data Scientist & Machine Learning',
  description:
    'Lulusan Matematika UGM yang membangun model machine learning, analisis data, dan riset kriptografi matematis.',
  role: 'Data Scientist, Machine Learning & Cryptography',
  email: 'amrul.yofan@gmail.com',
  links: {
    github: 'https://github.com/AmrulFY',
    linkedin: 'https://www.linkedin.com/in/amrul-fadhil-yofan-971048227',
    instagram: 'https://instagram.com/amrulyofan',
  },
  nav: [
    { href: '#about', label: 'About' },
    { href: '#projects', label: 'Projects' },
    { href: '#skills', label: 'Skills' },
    { href: '#contact', label: 'Contact' },
  ],
  skills: [
    { name: 'Python', items: ['Pandas', 'NumPy', 'SciPy'] },
    { name: 'ML & Deep Learning', items: ['Scikit-learn', 'PyTorch', 'TensorFlow'] },
    { name: 'Visualisasi data', items: ['Matplotlib', 'Seaborn', 'Power BI'] },
    { name: 'Web', items: ['HTML', 'CSS', 'JavaScript'] },
  ],
};

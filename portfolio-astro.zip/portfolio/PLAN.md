# Plan perbaikan portfolio (Fase 0–3)

Legenda: ✅ sudah tercakup di kerangka ini · ☐ masih perlu dikerjakan

## Fase 0 – Perbaikan bug situs lama (±1 hari)
Lewati bagian ini jika langsung migrasi ke kerangka Astro; semua bug kritis sudah teratasi di kerangka.
- ✅ Pisahkan `charset` dan `viewport` (viewport sebelumnya tidak berfungsi), tambah `lang`.
- ✅ Navigasi mobile berfungsi (class `nav-link`/`nav-links` konsisten, tombol menu + JS, `aria-expanded`).
- ✅ Hapus kode newsletter dan error `null` di inline script; hapus referensi `script.js` yang 404.
- ✅ Hapus AOS/animate.css/Font Awesome (animasi ganda, `once:false`, request pihak ketiga).
- ✅ Kartu memakai CSS grid `auto-fit` (tanpa lebar/tinggi tetap), `scroll-padding-top` untuk navbar tetap.
- ✅ Tombol navigasi jadi `<a href="#...">`, link eksternal memakai `rel="noopener noreferrer"`, hapus link Facebook generik, tahun otomatis.
- ✅ Landmark semantik (`header`, `nav`, `main`, `section`), skip link, `:focus-visible`, `prefers-reduced-motion`.

## Fase 1 – Desain dan konten (2–4 hari)
- ✅ Design tokens di `src/styles/tokens.css` (warna, tipografi `clamp()`, radius, spacing), font variabel self-host (bobot bold asli).
- ☐ Finalisasi arah visual: uji palet/typeface di `tokens.css`; tambahkan dark mode (`prefers-color-scheme`) dan toggle bila perlu.
- ☐ Isi tiap proyek: masalah, dataset, metode, metrik hasil (field `metric`), grafik/screenshot, tautan demo.
- ☐ Tambahkan bukti untuk klaim kriptografi (proyek/riset/tulisan) atau ubah headline agar sesuai.
- ☐ Section tambahan bila relevan: materi training/edukasi (mis. data BPS/OJK, konten @simplemath_id), tulisan/blog.
- ☐ Siapkan aset: `ft.png` → WebP/AVIF, `cv.pdf`, `og.png`.
- ☐ Satu momen animasi saja (mis. reveal hero), selebihnya statis.

## Fase 2 – Stack (3–5 hari)
- ✅ Astro 5 (output statis, nol JS default), komponen modular, content collection bertipe (zod) untuk proyek.
- ☐ Ikon: SVG inline (mis. Lucide/astro-icon) bila butuh ikon.
- ☐ Gambar: gunakan `astro:assets` agar otomatis responsif + format modern.
- ☐ Opsional: MDX untuk studi kasus panjang, section blog (`src/content/blog`), RSS.
- ☐ Opsional: Tailwind bila ingin utility-first; kerangka ini sengaja memakai CSS token biasa.
- ☐ Tambah ESLint + Prettier (+ `astro check` untuk tipe).

## Fase 3 – Production readiness (2–3 hari)
- ✅ Workflow deploy GitHub Pages, sitemap, `robots.txt`, meta description, Open Graph/Twitter card, canonical, JSON-LD `Person`, halaman 404, favicon.
- ☐ CI pada pull request: lint, `astro check`, build, cek tautan.
- ☐ Lighthouse CI dengan ambang: Performance ≥ 90, Accessibility ≥ 95, SEO ≥ 95, Best Practices ≥ 95.
- ☐ Uji aksesibilitas (axe) + uji manual keyboard dan screen reader; cek kontras warna.
- ☐ Custom domain + HTTPS (CNAME), update `site` di `astro.config.mjs` dan `robots.txt`.
- ☐ Analytics ramah privasi (Plausible/GoatCounter) dan pelaporan di README.
- ☐ Proteksi rantai pasok: Dependabot/Renovate, `package-lock.json` dikomit, SRI bila ada skrip eksternal.

## Urutan kerja yang disarankan
1. Jalankan kerangka, isi aset (Fase 1 aset) dan deploy sekali untuk memastikan pipeline hidup.
2. Lengkapi konten proyek dan klaim (Fase 1), karena paling berpengaruh pada kesan rekruter.
3. Selesaikan Fase 2 opsional sesuai kebutuhan, lalu Fase 3 (CI, Lighthouse, domain, analytics).
